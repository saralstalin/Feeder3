package net.azurewebsites.fishprice.feeder3;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;

import com.google.android.gms.appindexing.Action;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    JSONArray jsonArray;
    Spinner mySpinner = null;
    static String selectedRoute = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mySpinner = (Spinner) findViewById(R.id.SpinnerRoutes);
        if (savedInstanceState != null) {
            mySpinner.setSelection(savedInstanceState.getInt("mySpinner", 0));
        }
        mySpinner.setOnItemSelectedListener(this);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("mySpinner", mySpinner.getSelectedItemPosition());
        // do this for each or your Spinner
        // You might consider using Bundle.putStringArray() instead
    }

    @Override
    public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
        selectedRoute = mySpinner.getSelectedItem().toString();
        Intent intent = new Intent(MainActivity.this, FeederService.class);
        intent.putExtra("routeId", mySpinner.getSelectedItem().toString());
        startService(intent);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parentView) {
        // your code here
    }

    @Override
    public void onStart() {
        super.onStart();
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        new populateRoutes().execute(getString(R.string.routes_url) + "?dId=" + telephonyManager.getDeviceId());
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    private class populateRoutes extends AsyncTask<String, String, JSONArray> {
        protected JSONArray doInBackground(String... rurl) {
            JSONObject json = null;
            try {
                JSONParser jsonParser = new JSONParser();
                jsonArray = jsonParser.getJSONFromURL(rurl[0]);

                return jsonArray;
            } catch (Exception ex) {
            }
            return null;
        }

        @Override
        protected void onPostExecute(JSONArray result) {

            // TODO Auto-generated method stub
            //access UI elements here..
            TextView txtAccessMessage = (TextView) findViewById(R.id.textViewAccessMessage);
            // Spinner adapter
            try {
                final String[] items = new String[result.length()];
                if (result == null || result.length() == 0) {
                    txtAccessMessage.setText(getString(R.string.NoAccessMessage));
                    //stop the service. Service starts without this check intentionally to log new devices.
                    //Below code will not work properly with current implementation, hence commented
                    //stopService(new Intent(MainActivity.this, FeederService.class));
                    TableLayout tableLayout = (TableLayout) findViewById(R.id.tableRoutes);
                    tableLayout.setVisibility(View.GONE);

                } else {
                    for (int i = 0; i < result.length(); i++) {
                        JSONObject c = result.getJSONObject(i);
                        // Storing each json item in variable
                        items[i] = c.getString("RouteName");
                    }
                    ArrayAdapter<String> adapter =
                            new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item, items);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    mySpinner.setAdapter(adapter);
                    if(selectedRoute != "") {
                        setSpinnerValue(mySpinner, selectedRoute);
                    }

                }
                // looping through All Contacts
            } catch (Exception e) {
                e.printStackTrace();
            }
            //super.onPostExecute(result);
        }
    }

    public static void setSpinnerValue(Spinner spin, String value) {

        for (int i = 0; i < spin.getCount(); i++) {
            if (spin.getItemAtPosition(i).toString().equalsIgnoreCase(value)) {
                spin.setSelection(i);
                break;
            }

        }
    }
}

